INSERT INTO tb_professor(cpf, nome,email,senha )VALUES(52008821846,'victor','victor.umphir@gmail.com','123456')
INSERT INTO tb_aluno(cpf, nome,email,senha )VALUES(52008821844,'katia','katiavan@uol.com.br','123456')
