package br.com.fiap.produtomvc.controllers;

import br.com.fiap.produtomvc.dto.AlunoDTO;
import br.com.fiap.produtomvc.dto.ProfessorDTO;
import br.com.fiap.produtomvc.models.Professor;
import br.com.fiap.produtomvc.services.AlunoService;
import br.com.fiap.produtomvc.services.ProfessorService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/login")
public class LoginController {

    @Autowired
    private AlunoService alunoService;

    @Autowired
    private ProfessorService professorService;

    @GetMapping()
    public String showLoginForm() {
        return "login";
    }

    @PostMapping()
    public String login(@RequestParam String email, @RequestParam String senha, HttpSession session, Model model) {
        AlunoDTO aluno = alunoService.findAll().stream()
                .filter(a -> a.getEmail().equals(email) && a.getSenha().equals(senha))
                .findFirst().orElse(null);

        ProfessorDTO professor = professorService.findAll().stream()
                .filter(p -> p.getEmail().equals(email) && p.getSenha().equals(senha))
                .findFirst().orElse(null);

        if (aluno != null) {
            session.setAttribute("usuario", aluno); // Armazena o aluno na sessão
            return "redirect:/alunos/dashboard";
        } else if (professor != null) {
            session.setAttribute("usuario", professor); // Armazena o professor na sessão
            return "redirect:/professores/dashboard";
        } else {
            model.addAttribute("mensagem", "Email ou senha inválidos");
            return "login";
        }
    }
}
