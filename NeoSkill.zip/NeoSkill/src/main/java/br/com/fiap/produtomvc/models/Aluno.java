package br.com.fiap.produtomvc.models;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(exclude = {"nome"})

@Entity
@Table(name = "tb_aluno")
public class Aluno {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Campo requerido")
    @Size(min = 11, max = 11, message = "O CPF deve ter 11 caracteres")
    @Pattern(regexp = "\\d+", message = "O CPF deve conter apenas números")
    private String cpf;

    @NotBlank(message = "Campo requerido")
    @Size(min = 3,max = 50, message = "O nome deve ter no mínimo 3 caracteres")
    private String nome;

    @NotBlank(message = "Campo requerido")
    @Email(message = "Email inválido")
    private String email;

    @NotBlank(message = "Campo requerido")
    @Size(min = 6,  max = 10, message = "A senha deve ter no mínimo 6 caracteres e maximo de 10")
    private String senha;


}
