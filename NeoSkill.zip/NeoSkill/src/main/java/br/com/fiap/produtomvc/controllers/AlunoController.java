package br.com.fiap.produtomvc.controllers;

import br.com.fiap.produtomvc.dto.AlunoDTO;
import br.com.fiap.produtomvc.dto.VideoDTO;
import br.com.fiap.produtomvc.models.Video;
import br.com.fiap.produtomvc.services.AlunoService;
import br.com.fiap.produtomvc.services.VideoService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/alunos")
public class AlunoController {

    @Autowired
    private AlunoService service;

    @Autowired
    private VideoService videoService;
    @GetMapping("/form")
    public String loadFormAluno(Model model) {
        model.addAttribute("alunoDTO", new AlunoDTO());
        return "aluno/novo-aluno";
    }

    @PostMapping()
    public String insert(@Valid AlunoDTO alunoDTO,
                         BindingResult result,
                         RedirectAttributes attributes) {
        if (result.hasErrors()) {
            return "aluno/novo-aluno";
        }
        alunoDTO = service.insert(alunoDTO);
        attributes.addFlashAttribute("mensagem", "Aluno salvo com sucesso!");
        return "/login";
    }

    @GetMapping()
    public String findAll(Model model) {
        List<AlunoDTO> alunosDTO = service.findAll();
        model.addAttribute("alunosDTO", alunosDTO);
        return "/aluno/listar-alunos";
    }

    @GetMapping("/{id}")
    public String findById(@PathVariable("id") Long id, Model model) {
        AlunoDTO alunoDTO = service.findById(id);
        model.addAttribute("alunoDTO", alunoDTO);
        return "/aluno/editar-aluno";
    }

    @PutMapping("/{id}")
    public String update(@PathVariable("id") Long id,
                         @Valid AlunoDTO alunoDTO,
                         BindingResult result) {
        if (result.hasErrors()) {
            alunoDTO.setId(id);
            return "/aluno/editar-aluno";
        }
        service.update(id, alunoDTO);
        return "redirect:/alunos";
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable("id") Long id, Model model) {
        service.delete(id);
        return "redirect:/alunos";
    }
    @GetMapping("/dashboard")
    public String showProfessorDashboard(Model model) {
        // Adicione os dados necessários ao modelo
        model.addAttribute("progresso", 60); // Exemplo de progresso
        model.addAttribute("secoes", service.getSecoes()); // Método fictício para obter seções
        model.addAttribute("descricoes", service.getDescricoes()); // Método fictício para obter descrições
        model.addAttribute("tipo", service.getSecoes()); // Método fictício para obter descrições
        model.addAttribute("videos", videoService.findAll()); // Adiciona os vídeos ao modelo
        return "aluno-dashboard";
    }
    @GetMapping("/perfilAluno")
    public String perfilAluno(HttpSession session, Model model) {
        AlunoDTO aluno = (AlunoDTO) session.getAttribute("usuario");

        if (aluno == null) {
            model.addAttribute("mensagem", "Usuário não encontrado na sessão. Faça login novamente.");
            return "redirect:/login"; // Redireciona para o login se o aluno não estiver na sessão
        }

        model.addAttribute("nome", aluno.getNome());
        model.addAttribute("email", aluno.getEmail());

        return "PerfilAluno"; // Retorna a visão do perfil do aluno
    }
}

