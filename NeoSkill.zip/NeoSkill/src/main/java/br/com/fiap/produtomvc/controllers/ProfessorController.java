package br.com.fiap.produtomvc.controllers;

import br.com.fiap.produtomvc.dto.ProfessorDTO;
import br.com.fiap.produtomvc.dto.VideoDTO;

import br.com.fiap.produtomvc.services.ProfessorService;
import br.com.fiap.produtomvc.services.VideoService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/professores")
public class ProfessorController {

    @Autowired
    private ProfessorService service;


    @Autowired
    private VideoService videoService;

    @GetMapping("/form")
    public String loadFormProfessor(Model model) {
        model.addAttribute("professorDTO", new ProfessorDTO());
        return "professor/novo-professor";
    }

    @PostMapping()
    public String insert(@Valid ProfessorDTO professorDTO,
                         BindingResult result,
                         RedirectAttributes attributes) {
        if (result.hasErrors()) {
            return "professor/novo-professor";
        }
        professorDTO = service.insert(professorDTO);
        attributes.addFlashAttribute("mensagem", "Professor salvo com sucesso!");
        return "redirect:/login";
    }

    @GetMapping()
    public String findAll(Model model) {
        List<ProfessorDTO> professoresDTO = service.findAll();
        model.addAttribute("professoresDTO", professoresDTO);
        return "/professor/listar-professores";
    }

    @GetMapping("/{id}")
    public String findById(@PathVariable("id") Long id, Model model) {
        ProfessorDTO professorDTO = service.findById(id);
        model.addAttribute("professorDTO", professorDTO);
        return "/professor/editar-professor";
    }

    @PutMapping("/{id}")
    public String update(@PathVariable("id") Long id,
                         @Valid ProfessorDTO professorDTO,
                         BindingResult result) {
        if (result.hasErrors()) {
            professorDTO.setId(id);
            return "/professor/editar-professor";
        }
        service.update(id, professorDTO);
        return "redirect:/professores";
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable("id") Long id, Model model) {
        service.delete(id);
        return "redirect:/professores";
    }

    @GetMapping("/dashboard")
    public String showProfessorDashboard(Model model) {
        // Adicione os dados necessários ao modelo
        model.addAttribute("progresso", 60); // Exemplo de progresso
        model.addAttribute("secoes", service.getSecoes()); // Método fictício para obter seções
        model.addAttribute("descricoes", service.getDescricoes()); // Método fictício para obter descrições
        model.addAttribute("tipo", service.getSecoes()); // Método fictício para obter descrições
        model.addAttribute("videos", videoService.findAll()); // Adiciona os vídeos ao modelo
        return "professor-dashboard";
    }

    @PostMapping("/upload-video")
    public String uploadVideo(@RequestParam("titulo") String titulo,
                              @RequestParam("descricao") String descricao,
                              @RequestParam("file") MultipartFile file,
                              @RequestParam("secao") int secao,
                              RedirectAttributes attributes) {
        VideoDTO videoDTO = new VideoDTO();
        videoDTO.setTitulo(titulo);
        videoDTO.setDescricao(descricao);
        videoDTO.setSecao(secao);

        try {
            videoService.saveVideo(videoDTO, file);
            attributes.addFlashAttribute("mensagem", "Vídeo enviado com sucesso!");
        } catch (IOException e) {
            attributes.addFlashAttribute("mensagem", "Erro ao enviar vídeo: " + e.getMessage());
        }

        return "redirect:/professores/dashboard";
    }
    @GetMapping("/cadastro")
    public String cadastro(Model model) {
        // Adicione os dados necessários ao modelo

        model.addAttribute("secoes", service.getSecoes()); // Método fictício para obter seções
        model.addAttribute("descricoes", service.getDescricoes()); // Método fictício para obter descrições
        model.addAttribute("tipo", service.getSecoes()); // Método fictício para obter descrições
        model.addAttribute("videos", videoService.findAll()); // Adiciona os vídeos ao modelo
        return "/cadastro";
    }


    @GetMapping("/perfil")
    public String showProfile(HttpSession session, Model model) {
        ProfessorDTO professor = (ProfessorDTO) session.getAttribute("usuario");

        if (professor == null) {
            model.addAttribute("mensagem", "Usuário não encontrado na sessão. Faça login novamente.");
            System.out.println("Professor encontrado: " + professor.getNome() + " - " + professor.getEmail());
            return "redirect:/login"; // Redireciona para o login se o professor não estiver na sessão
        }

        model.addAttribute("nome", professor.getNome());
        model.addAttribute("email", professor.getEmail());

        return "perfil"; // Retorna a visão do perfil
    }

}
