package br.com.fiap.produtomvc.services;


import br.com.fiap.produtomvc.dto.ProfessorDTO;
import br.com.fiap.produtomvc.models.Professor;
import br.com.fiap.produtomvc.repository.ProfessorRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProfessorService {
    @Autowired
    private ProfessorRepository repository;



    @Transactional(readOnly = true)
    public List<ProfessorDTO> findAll() {
        List<Professor> list = repository.findAll();
        return list.stream().map(ProfessorDTO::new).collect(Collectors.toList());
    }

    @Transactional
    public ProfessorDTO insert(ProfessorDTO dto) {
        Professor entity = new Professor();
        copyDtoToEntity(dto, entity);
        entity = repository.save(entity);
        return new ProfessorDTO(entity);
    }

    @Transactional(readOnly = true)
    public ProfessorDTO findById(Long id) {
        Professor professor = repository.findById(id).orElseThrow(
                () -> new IllegalArgumentException("Recurso inválido - " + id)
        );
        return new ProfessorDTO(professor);
    }

    @Transactional
    public ProfessorDTO update(Long id, ProfessorDTO dto) {
        try {
            Professor entity = repository.getReferenceById(id);
            copyDtoToEntity(dto, entity);
            entity = repository.save(entity);
            return new ProfessorDTO(entity);
        } catch (EntityNotFoundException e) {
            throw new IllegalArgumentException("Recurso não encontrado");
        }
    }

    @Transactional
    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new IllegalArgumentException("Recurso inválido - id: " + id);
        }
        try {
            repository.deleteById(id);
        } catch (DataIntegrityViolationException e) {
            throw new IllegalArgumentException("Falha de integridade referencial - id: " + id);
        }
    }

    private void copyDtoToEntity(ProfessorDTO dto, Professor entity) {
        entity.setCpf(dto.getCpf());
        entity.setNome(dto.getNome());
        entity.setEmail(dto.getEmail());
        entity.setSenha(dto.getSenha());
    }
    public List<String> getSecoes() {
        // Exemplo de seções
        return Arrays.asList("Seção de cursos 1", "Seção de cursos 2", "Seção de cursos 3", "Seção de cursos 4", "Seção de cursos 5", "Seção de cursos 6");
    }

    public List<String> getDescricoes() {
        // Exemplo de descrições
        return Arrays.asList("Descrição do tipo 1", "Descrição do tipo 2", "Descrição do tipo 3", "Descrição do tipo 4", "Descrição do tipo 5");
    }

    public class ProfessorNotFoundException extends RuntimeException {
        public ProfessorNotFoundException(String message) {
            super(message);
        }
    }


    public ProfessorDTO getProfessorLogado(String email, String nome) throws Exception {
        Professor professor = repository.findByEmailAndNome(email,nome).orElseThrow(() -> new Exception("Professor não encontrado"));
        return new ProfessorDTO(professor);
    }


}
