package br.com.fiap.produtomvc.repository;



import br.com.fiap.produtomvc.models.Video;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VideoRepository extends JpaRepository<Video, Long> {
}

