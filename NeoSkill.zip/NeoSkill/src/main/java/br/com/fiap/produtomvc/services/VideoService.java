package br.com.fiap.produtomvc.services;

import br.com.fiap.produtomvc.dto.VideoDTO;
import br.com.fiap.produtomvc.models.Video;

import br.com.fiap.produtomvc.repository.VideoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class VideoService {

    @Autowired
    private VideoRepository videoRepository;

    public VideoDTO saveVideo(VideoDTO videoDTO, MultipartFile file) throws IOException {
        // Salvar o arquivo de vídeo em algum lugar e obter a URL
        String videoUrl = saveFile(file);

        Video video = new Video();
        video.setTitulo(videoDTO.getTitulo());
        video.setDescricao(videoDTO.getDescricao());
        video.setUrl(videoUrl);

        video = videoRepository.save(video);

        videoDTO.setId(video.getId());
        videoDTO.setUrl(video.getUrl());

        return videoDTO;
    }

    public List<VideoDTO> findAll() {
        return videoRepository.findAll().stream().map(video -> {
            VideoDTO dto = new VideoDTO();
            dto.setId(video.getId());
            dto.setTitulo(video.getTitulo());
            dto.setDescricao(video.getDescricao());
            dto.setUrl(video.getUrl());
            return dto;
        }).collect(Collectors.toList());
    }

    private String saveFile(MultipartFile file) throws IOException {
        // Lógica para salvar o arquivo e retornar a URL
        // Por exemplo, salvar no sistema de arquivos ou em um serviço de armazenamento na nuvem
        return "url_do_video";
    }
}
