package br.com.fiap.produtomvc.repository;

import br.com.fiap.produtomvc.models.Aluno;
import br.com.fiap.produtomvc.models.Professor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AlunoRepository extends JpaRepository<Aluno, Long> {
}
