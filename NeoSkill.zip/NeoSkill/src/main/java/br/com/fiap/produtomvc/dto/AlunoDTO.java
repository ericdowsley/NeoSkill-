package br.com.fiap.produtomvc.dto;

import br.com.fiap.produtomvc.models.Aluno;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class AlunoDTO {

    private Long id;

    @NotBlank(message = "Campo requerido")
    @Size(min = 11, max = 11, message = "O CPF deve ter 11 caracteres")
    @Pattern(regexp = "\\d+", message = "O CPF deve conter apenas números")
    private String cpf;

    @NotBlank(message = "Campo requerido")
    @Size(min = 3,max = 50, message = "O nome deve ter no mínimo 3 e no máximo 50 caracteres")
    private String nome;

    @NotBlank(message = "Campo requerido")
    @Email(message = "Email inválido")
    private String email;

    @NotBlank(message = "Campo requerido")
    @Size(min = 6, max = 10, message = "A senha deve ter no mínimo 6 e maximo de 10 caracteres")
    private String senha;

    public AlunoDTO(Aluno entity) {
        id = entity.getId();
        cpf = entity.getCpf();
        nome = entity.getNome();
        email = entity.getEmail();
        senha = entity.getSenha();
    }

}

