package br.com.fiap.produtomvc.controllers;

import br.com.fiap.produtomvc.dto.ProfessorDTO;
import br.com.fiap.produtomvc.dto.VideoDTO;

import br.com.fiap.produtomvc.models.Professor;
import br.com.fiap.produtomvc.services.ProfessorService;
import br.com.fiap.produtomvc.services.VideoService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.util.List;

import static java.lang.System.out;


@Controller
@RequestMapping("/professores")
public class ProfessorController {

    @Autowired
    private ProfessorService service;


    @Autowired
    private VideoService videoService;

    @GetMapping("/form")
    public String loadFormProfessor(Model model) {
        model.addAttribute("professorDTO", new ProfessorDTO());
        return "professor/novo-professor";
    }

    @PostMapping()
    public String insert(@Valid ProfessorDTO professorDTO,
                         BindingResult result,
                         RedirectAttributes attributes) {
        if (result.hasErrors()) {
            return "professor/novo-professor";
        }
        professorDTO = service.insert(professorDTO);
        attributes.addFlashAttribute("mensagem", "Professor salvo com sucesso!");
        return "redirect:/login";
    }

    @GetMapping()
    public String findAll(Model model) {
        List<ProfessorDTO> professoresDTO = service.findAll();
        model.addAttribute("professoresDTO", professoresDTO);
        return "/professor/listar-professores";
    }

    @GetMapping("/{id}")
    public String findById(@PathVariable("id") Long id, Model model) {
        ProfessorDTO professorDTO = service.findById(id);
        model.addAttribute("professorDTO", professorDTO);
        return "/professor/editar-professor";
    }

    @PutMapping("/{id}")
    public String update(@PathVariable("id") Long id,
                         @Valid ProfessorDTO professorDTO,
                         BindingResult result) throws Exception {
        if (result.hasErrors()) {
            professorDTO.setId(id);
            return "/professor/editar-professor";
        }
        service.update(id, professorDTO);
        return "redirect:/professores";
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable("id") Long id, Model model) {
        service.delete(id);
        return "redirect:/professores";
    }

    @GetMapping("/dashboard")
    public String showProfessorDashboard(Model model) {
        // Adicione os dados necessários ao modelo
        model.addAttribute("progresso", 60); // Exemplo de progresso
        model.addAttribute("secoes", service.getSecoes()); // Método fictício para obter seções
        model.addAttribute("descricoes", service.getDescricoes()); // Método fictício para obter descrições
        model.addAttribute("tipo", service.getSecoes()); // Método fictício para obter descrições
        model.addAttribute("videos", videoService.findAll()); // Adiciona os vídeos ao modelo
        return "professor-dashboard";
    }

    @PostMapping("/upload-video")
    public String uploadVideo(@RequestParam("titulo") String titulo,
                              @RequestParam("descricao") String descricao,
                              @RequestParam("url") String url,
                              @RequestParam("secao") String secao,
                              HttpSession session,
                              RedirectAttributes redirectAttributes) {
        ProfessorDTO professorDTO = (ProfessorDTO) session.getAttribute("usuario");
        if (professorDTO == null) {
            redirectAttributes.addFlashAttribute("erro", "Professor não está logado");
            return "redirect:/login";
        }

        VideoDTO videoDTO = new VideoDTO();
        videoDTO.setTitulo(titulo);
        videoDTO.setDescricao(descricao);
        videoDTO.setUrl(url);
        videoDTO.setSecao(secao);

        try {
            Professor professor = service.convertDTOToEntity(professorDTO);
            VideoDTO savedVideo = videoService.saveVideo(videoDTO, professor);
            redirectAttributes.addFlashAttribute("mensagem", "Vídeo adicionado com sucesso!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("erro", "Erro ao adicionar vídeo: " + e.getMessage());
        }

        return "redirect:/professores/dashboard";
    }

    @GetMapping("/cadastro")
    public String cadastro(Model model) {
        // Adicione os dados necessários ao modelo

        model.addAttribute("secoes", service.getSecoes()); // Método fictício para obter seções
        model.addAttribute("descricoes", service.getDescricoes()); // Método fictício para obter descrições
        model.addAttribute("tipo", service.getSecoes()); // Método fictício para obter descrições
        model.addAttribute("videos", videoService.findAll()); // Adiciona os vídeos ao modelo
        return "/cadastro";
    }

    @GetMapping("/perfil")
    public String showProfile(HttpSession session, Model model) {
        ProfessorDTO professor = (ProfessorDTO) session.getAttribute("usuario");

        if (professor == null) {
            // Log para debug
            out.println("Professor não encontrado na sessão");
            return "redirect:/login";
        }

        // Log para debug
        out.println("Professor encontrado: " + professor.getNome() + " - " + professor.getEmail());

        model.addAttribute("professor", professor);
        return "perfil";
    }

    @GetMapping("/perfil/editar")
    public String editProfile(HttpSession session, Model model) {
        ProfessorDTO professor = (ProfessorDTO) session.getAttribute("usuario");

        if (professor == null) {
            // Log para debug
            out.println("Professor não encontrado na sessão ao tentar editar");
            return "redirect:/login";
        }

        model.addAttribute("professor", professor);
        return "editar-perfil";
    }

    @PostMapping("/perfil/atualizar")
    public String updateProfile(@ModelAttribute ProfessorDTO professorDTO,
                                BindingResult result,
                                HttpSession session,
                                RedirectAttributes attributes) {
        if (result.hasErrors()) {
            return "editar-perfil";
        }

        try {
            ProfessorDTO updatedProfessor = service.update(professorDTO.getId(), professorDTO);
            session.setAttribute("usuario", updatedProfessor);
            attributes.addFlashAttribute("mensagem", "Perfil atualizado com sucesso!");
        } catch (Exception e) {
            attributes.addFlashAttribute("erro", "Erro ao atualizar perfil: " + e.getMessage());
            // Log the exception
            e.printStackTrace();
        }

        return "redirect:/professores/perfil";
    }

}