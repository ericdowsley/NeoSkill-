package br.com.fiap.produtomvc.controllers;

import br.com.fiap.produtomvc.models.FormularioPresencial;
import br.com.fiap.produtomvc.models.Professor;
import br.com.fiap.produtomvc.repository.FormularioPresencialRepository;
import br.com.fiap.produtomvc.repository.ProfessorRepository;
import jakarta.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/formularios")
public class FormularioPresencialController {

    @Autowired
    private FormularioPresencialRepository formularioPresencialRepository;

    @Autowired
    private ProfessorRepository professorRepository;

    @GetMapping("/novo")
    public String mostrarNovoFormulario(Model model) {
        model.addAttribute("formularioPresencial", new FormularioPresencial());
        return "formularios/novo-formulario";
    }

    @PostMapping("/novo")
    public String salvarNovoFormulario(@ModelAttribute FormularioPresencial formularioPresencial) {
        try {
            // For simplicity, we'll use a placeholder Professor
            // In a real scenario, you'd get this from your session or however you're tracking the logged-in user
            Professor professor = professorRepository.findById(1L)
                    .orElseThrow(() -> new RuntimeException("Professor not found"));

            formularioPresencial.setCriador(professor);
            FormularioPresencial saved = formularioPresencialRepository.save(formularioPresencial);

            return "redirect:/formularios/listar";
        } catch (Exception e) {
            // Log the error
            e.printStackTrace();
            return "error/formulario-error";
        }
    }

    @GetMapping("/listar")
    public String listarFormularios(Model model) {
        model.addAttribute("formularios", formularioPresencialRepository.findAll());
        return "formularios/listar";
    }
    @GetMapping("/{id}")
    @Transactional(readOnly = true)
    public String visualizarFormulario(@PathVariable Long id, Model model) {
        FormularioPresencial formulario = formularioPresencialRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Formulário não encontrado"));
        model.addAttribute("formulario", formulario);
        return "formularios/visualizar";
    }

    @GetMapping("/{id}/editar")
    public String mostrarFormularioEditar(@PathVariable Long id, Model model) {
        FormularioPresencial formulario = formularioPresencialRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Formulário inválido: " + id));
        model.addAttribute("formulario", formulario);
        return "formularios/editar";
    }


    @PostMapping("/{id}/excluir")
    public String excluirFormulario(@PathVariable Long id) {
        formularioPresencialRepository.deleteById(id);
        return "redirect:/formularios/listar";
    }
}