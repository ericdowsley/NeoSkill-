package br.com.fiap.produtomvc.services;


import br.com.fiap.produtomvc.dto.ProfessorDTO;
import br.com.fiap.produtomvc.models.Professor;
import br.com.fiap.produtomvc.repository.ProfessorRepository;
import jakarta.persistence.EntityNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ProfessorService {
    @Autowired
    private ProfessorRepository repository;

    private static final Logger logger = LoggerFactory.getLogger(ProfessorService.class);

    @Transactional(readOnly = true)
    public List<ProfessorDTO> findAll() {
        List<Professor> list = repository.findAll();
        return list.stream().map(ProfessorDTO::new).collect(Collectors.toList());
    }

    @Transactional
    public ProfessorDTO insert(ProfessorDTO dto) {
        Professor entity = new Professor();
        copyDtoToEntity(dto, entity);
        entity = repository.save(entity);
        return new ProfessorDTO(entity);
    }

    @Transactional(readOnly = true)
    public ProfessorDTO findById(Long id) {
        Professor professor = repository.findById(id).orElseThrow(
                () -> new IllegalArgumentException("Recurso inválido - " + id)
        );
        return new ProfessorDTO(professor);
    }

    @Transactional
    public ProfessorDTO update(Long id, ProfessorDTO dto) {
        try {
            logger.info("Attempting to update professor with ID: {}", id);
            Professor entity = repository.findById(id)
                    .orElseThrow(() -> new ProfessorNotFoundException("Professor não encontrado - ID: " + id));

            logger.debug("Found professor: {}", entity);
            copyDtoToUpdate(dto, entity);

            entity = repository.save(entity);
            logger.info("Professor updated successfully. ID: {}", entity.getId());

            return new ProfessorDTO(entity);
        } catch (Exception e) {
            logger.error("Error updating professor with ID: {}. Error: {}", id, e.getMessage(), e);
            throw new RuntimeException("Erro ao atualizar professor", e);
        }

    }

    @Transactional
    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new IllegalArgumentException("Recurso inválido - id: " + id);
        }
        try {
            repository.deleteById(id);
        } catch (DataIntegrityViolationException e) {
            throw new IllegalArgumentException("Falha de integridade referencial - id: " + id);
        }
    }

    private void copyDtoToEntity(ProfessorDTO dto, Professor entity) {
        entity.setCpf(dto.getCpf());
        entity.setNome(dto.getNome());
        entity.setEmail(dto.getEmail());
        entity.setSenha(dto.getSenha());
    }
    private void copyDtoToUpdate(ProfessorDTO dto, Professor entity) {
        entity.setNome(dto.getNome());
        entity.setEmail(dto.getEmail());

    }
    public List<String> getSecoes() {
        // Exemplo de seções
        return Arrays.asList("Seção de cursos 1", "Seção de cursos 2", "Seção de cursos 3", "Seção de cursos 4", "Seção de cursos 5", "Seção de cursos 6");
    }

    public List<String> getDescricoes() {
        // Exemplo de descrições
        return Arrays.asList("Descrição do tipo 1", "Descrição do tipo 2", "Descrição do tipo 3", "Descrição do tipo 4", "Descrição do tipo 5");
    }

    public class ProfessorNotFoundException extends RuntimeException {
        public ProfessorNotFoundException(String message) {
            super(message);
        }
    }
    private ProfessorDTO convertToDTO(Professor professor) {
        ProfessorDTO dto = new ProfessorDTO();
        dto.setId(professor.getId());
        dto.setNome(professor.getNome());
        dto.setEmail(professor.getEmail());

        return dto;
    }
    public Professor findEntityById(Long professorId) {
        return repository.findById(professorId)
                .orElseThrow(() -> new RuntimeException("Professor não encontrado com ID: " + professorId));
    }


    public Professor convertDTOToEntity(ProfessorDTO dto) {
        if (dto == null) return null;
        Professor professor = new Professor();
        professor.setId(dto.getId());
        professor.setNome(dto.getNome());
        professor.setEmail(dto.getEmail());
        professor.setCpf(dto.getCpf());
        professor.setSenha(dto.getSenha());
        // Adicione outros campos conforme necessário
        return professor;
    }
    public boolean isEmailUnique(String email) {
        return !repository.existsByEmail(email);
    }

    public boolean isCpfUnique(String cpf) {
        return !repository.existsByCpf(cpf);
    }


    public static class DuplicateEmailException extends RuntimeException {
        public DuplicateEmailException(String message) {
            super(message);
        }
    }

    public static class DuplicateCpfException extends RuntimeException {
        public DuplicateCpfException(String message) {
            super(message);
        }
    }
}
