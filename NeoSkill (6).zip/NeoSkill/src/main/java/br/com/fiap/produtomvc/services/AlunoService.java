package br.com.fiap.produtomvc.services;

import br.com.fiap.produtomvc.dto.AlunoDTO;
import br.com.fiap.produtomvc.dto.ProfessorDTO;
import br.com.fiap.produtomvc.models.Aluno;
import br.com.fiap.produtomvc.models.Professor;
import br.com.fiap.produtomvc.repository.AlunoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AlunoService {
    private static final Logger logger = LoggerFactory.getLogger(AlunoService.class);

    @Autowired
    private AlunoRepository repository;

    @Transactional(readOnly = true)
    public List<AlunoDTO> findAll() {
        List<Aluno> list = repository.findAll();
        return list.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Transactional
    public AlunoDTO insert(AlunoDTO dto) {
        Aluno entity = new Aluno();
        copyDtoToEntity(dto, entity);
        entity.setProgresso(0.0); // Inicializa o progresso como 0
        entity = repository.save(entity);
        return convertToDTO(entity);
    }

    @Transactional(readOnly = true)
    public AlunoDTO findById(Long id) {
        Aluno aluno = repository.findById(id)
                .orElseThrow(() -> new AlunoNotFoundException("Aluno não encontrado - ID: " + id));
        return convertToDTO(aluno);
    }

    @Transactional
    public AlunoDTO update(Long id, AlunoDTO dto) {
        try {
            logger.info("Attempting to update professor with ID: {}", id);
            Aluno entity = repository.findById(id)
                    .orElseThrow(() -> new AlunoService.AlunoNotFoundException("Professor não encontrado - ID: " + id));

            logger.debug("Found aluno: {}", entity);
            copyDtoToUpdate(dto, entity);

            entity = repository.save(entity);
            logger.info("Aluno updated successfully. ID: {}", entity.getId());

            return new AlunoDTO(entity);
        } catch (Exception e) {
            logger.error("Error updating aluno with ID: {}. Error: {}", id, e.getMessage(), e);
            throw new RuntimeException("Erro ao atualizar professor", e);
        }

    }

    @Transactional
    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new AlunoNotFoundException("Aluno não encontrado - ID: " + id);
        }
        try {
            repository.deleteById(id);
        } catch (DataIntegrityViolationException e) {
            throw new IllegalArgumentException("Falha de integridade referencial - id: " + id);
        }
    }

    @Transactional
    public void updateProgresso(Long alunoId, Double novoProgresso) {
        Aluno aluno = repository.findById(alunoId)
                .orElseThrow(() -> new AlunoNotFoundException("Aluno não encontrado - ID: " + alunoId));
        aluno.setProgresso(novoProgresso);
        repository.save(aluno);
    }

    private void copyDtoToEntity(AlunoDTO dto, Aluno entity) {
        entity.setCpf(dto.getCpf());
        entity.setNome(dto.getNome());
        entity.setEmail(dto.getEmail());
        entity.setSenha(dto.getSenha());
        entity.setProgresso(dto.getProgresso());
    }

    private void copyDtoToUpdate(AlunoDTO dto, Aluno entity) {
        entity.setNome(dto.getNome());
        entity.setEmail(dto.getEmail());
       if (dto.getProgresso() != null) {
           entity.setProgresso(dto.getProgresso());
         }
    }

    private AlunoDTO convertToDTO(Aluno aluno) {
        AlunoDTO dto = new AlunoDTO();
        dto.setId(aluno.getId());
        dto.setNome(aluno.getNome());
        dto.setEmail(aluno.getEmail());
        dto.setCpf(aluno.getCpf());
        dto.setSenha(aluno.getSenha());
        dto.setProgresso(aluno.getProgresso());
        return dto;
    }

    public static class AlunoNotFoundException extends RuntimeException {
        public AlunoNotFoundException(String message) {
            super(message);
        }
    }

    public boolean isEmailUnique(String email) {
        return !repository.existsByEmail(email);
    }

    public boolean isCpfUnique(String cpf) {
        return !repository.existsByCpf(cpf);
    }

    public static class DuplicateEmailException extends RuntimeException {
        public DuplicateEmailException(String message) {
            super(message);
        }
    }

    public static class DuplicateCpfException extends RuntimeException {
        public DuplicateCpfException(String message) {
            super(message);
        }
    }

}