    package br.com.fiap.produtomvc.controllers;

    import br.com.fiap.produtomvc.dto.AlunoDTO;
    import br.com.fiap.produtomvc.dto.ProfessorDTO;
    import br.com.fiap.produtomvc.dto.VideoDTO;
    import br.com.fiap.produtomvc.models.Professor;
    import br.com.fiap.produtomvc.services.VideoService;
    import br.com.fiap.produtomvc.services.ProfessorService;
    import jakarta.servlet.http.HttpSession;
    import jakarta.validation.Valid;
    import org.springframework.beans.factory.annotation.Autowired;
    import org.springframework.stereotype.Controller;
    import org.springframework.ui.Model;
    import org.springframework.validation.BindingResult;
    import org.springframework.web.bind.annotation.*;
    import org.springframework.web.servlet.mvc.support.RedirectAttributes;

    import java.util.List;

    @Controller
    @RequestMapping("/videos")
    public class VideoController {

        @Autowired
        private VideoService videoService;

        @Autowired
        private ProfessorService professorService;

        @GetMapping
        public String listVideos(Model model) {
            List<VideoDTO> videos = videoService.findAll();
            model.addAttribute("videos", videos);
            return "video/listar-videos";
        }

        @GetMapping("/{id}")
        public String viewVideo(@PathVariable Long id, Model model, HttpSession session) {
            VideoDTO video = videoService.findById(id);
            if (video == null) {
                return "redirect:/error";
            }

            model.addAttribute("video", video);

            // Check user type from session
            String tipoUsuario = (String) session.getAttribute("tipoUsuario");

            if ("aluno".equals(tipoUsuario)) {
                // If it's a student, add student-specific attributes if needed
                AlunoDTO aluno = (AlunoDTO) session.getAttribute("usuario");
                model.addAttribute("aluno", aluno);
                return "video/visualizar-videoaluno";
            } else if ("professor".equals(tipoUsuario)) {
                // If it's a teacher, add teacher-specific attributes if needed
                ProfessorDTO professor = (ProfessorDTO) session.getAttribute("usuario");
                model.addAttribute("professor", professor);
                return "video/visualizar-video";
            } else {
                // If user type is not recognized, redirect to login
                return "redirect:/login";
            }
        }

        @GetMapping("/voltar")
        public String goBack(HttpSession session) {
            String tipoUsuario = (String) session.getAttribute("tipoUsuario");

            if ("aluno".equals(tipoUsuario)) {
                return "redirect:/alunos/dashboard";
            } else if ("professor".equals(tipoUsuario)) {
                return "redirect:/professores/dashboard";
            } else {
                return "redirect:/login";
            }
        }


        @GetMapping("/new")
        public String newVideoForm(Model model) {
            model.addAttribute("videoDTO", new VideoDTO());
            return "video/visualizar-video";
        }

        @PostMapping
        public String createVideo(@Valid @ModelAttribute VideoDTO videoDTO,
                                  BindingResult result,
                                  HttpSession session,
                                  RedirectAttributes redirectAttributes) {
            if (result.hasErrors()) {
                return "video/visualizar-video";
            }

            ProfessorDTO professorDTO = (ProfessorDTO) session.getAttribute("usuario");
            if (professorDTO == null) {
                redirectAttributes.addFlashAttribute("erro", "Professor não está logado");
                return "redirect:/login";
            }

            try {
                Professor professor = professorService.findEntityById(professorDTO.getId());
                if (professor == null) {
                    redirectAttributes.addFlashAttribute("erro", "Professor não encontrado");
                    return "redirect:/login";
                }

                videoDTO.setProfessorId(professor.getId());
                videoService.saveVideo(videoDTO, professor);
                redirectAttributes.addFlashAttribute("mensagem", "Vídeo adicionado com sucesso");
            } catch (Exception e) {
                redirectAttributes.addFlashAttribute("erro", "Erro ao adicionar vídeo: " + e.getMessage());
            }

            return "redirect:/videos";
        }
        @GetMapping("/{id}/edit")
        public String editVideoForm(@PathVariable Long id, Model model) {
            VideoDTO video = videoService.findById(id);
            model.addAttribute("videoDTO", video);
            return "video/editar-video";
        }

        @PostMapping("/{id}")
        public String updateVideo(@PathVariable Long id,
                                  @Valid @ModelAttribute VideoDTO videoDTO,
                                  BindingResult result,
                                  RedirectAttributes redirectAttributes) {
            if (result.hasErrors()) {
                return "video/editar-video";
            }

            try {
                videoService.updateVideo(id, videoDTO);
                redirectAttributes.addFlashAttribute("mensagem", "Vídeo atualizado com sucesso");
            } catch (Exception e) {
                redirectAttributes.addFlashAttribute("erro", "Erro ao atualizar vídeo: " + e.getMessage());
            }

            return "redirect:/videos";
        }

        @PostMapping("/{id}/delete")
        public String deleteVideo(@PathVariable Long id, RedirectAttributes redirectAttributes) {
            try {
                videoService.deleteVideo(id);
                redirectAttributes.addFlashAttribute("mensagem", "Vídeo excluído com sucesso");
            } catch (Exception e) {
                redirectAttributes.addFlashAttribute("erro", "Erro ao excluir vídeo: " + e.getMessage());
            }

            return "redirect:/videos";
        }

        @GetMapping("/search")
        public String searchVideos(@RequestParam String termo, Model model) {
            List<VideoDTO> videos = videoService.findByTitulo(termo);
            model.addAttribute("videos", videos);
            return "video/listar-videos";
        }

        @GetMapping("/secao/{secao}")
        public String videosPorSecao(@PathVariable String secao, Model model) {
            List<VideoDTO> videos = videoService.findBySecao(secao);
            model.addAttribute("videos", videos);
            return "video/listar-videos";
        }
    }