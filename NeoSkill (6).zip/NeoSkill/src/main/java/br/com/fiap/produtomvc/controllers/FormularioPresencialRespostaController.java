package br.com.fiap.produtomvc.controllers;

import br.com.fiap.produtomvc.models.Aluno;
import br.com.fiap.produtomvc.models.FormularioPresencial;
import br.com.fiap.produtomvc.models.FormularioPresencialResposta;
import br.com.fiap.produtomvc.repository.FormularioPresencialRepository;
import br.com.fiap.produtomvc.repository.FormularioPresencialRespostaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Controller
@RequestMapping("/respostas")
public class FormularioPresencialRespostaController {

    @Autowired
    private FormularioPresencialRepository formularioPresencialRepository;

    @Autowired
    private FormularioPresencialRespostaRepository respostaRepository;

    @GetMapping("/formulario/{id}")
    public String mostrarFormularioResposta(@PathVariable Long id, Model model) {
        FormularioPresencial formulario = formularioPresencialRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Formulário inválido: " + id));
        model.addAttribute("formulario", formulario);
        return "respostas/responder";
    }

    @PostMapping("/formulario/{id}")
    public String responderFormulario(@PathVariable Long id,
                                      @RequestParam Map<String, String> respostas,
                                      Aluno user) {
        FormularioPresencial formulario = formularioPresencialRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Formulário inválido: " + id));

        FormularioPresencialResposta resposta = FormularioPresencialResposta.builder()
                .formulario(formulario)
                .respondente(user)
                .respostas(respostas)
                .build();

        respostaRepository.save(resposta);

        return "redirect:/respostas/confirmacao";
    }

    @GetMapping("/confirmacao")
    public String mostrarConfirmacao() {
        return "respostas/confirmacao";
    }

    @GetMapping("/listar/{formularioId}")
    public String listarRespostas(@PathVariable Long formularioId, Model model) {
        FormularioPresencial formulario = formularioPresencialRepository.findById(formularioId)
                .orElseThrow(() -> new IllegalArgumentException("Formulário inválido: " + formularioId));
        model.addAttribute("formulario", formulario);
        model.addAttribute("respostas", respostaRepository.findByFormulario(formulario));
        return "respostas/listar";
    }
}