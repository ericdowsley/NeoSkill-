package br.com.fiap.produtomvc.repository;

import br.com.fiap.produtomvc.models.Video;
import br.com.fiap.produtomvc.models.Professor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface VideoRepository extends JpaRepository<Video, Long> {

    List<Video> findByProfessor(Professor professor);

    @Query("SELECT v FROM Video v WHERE v.professor.id = :professorId")
    List<Video> findByProfessorId(@Param("professorId") Long professorId);

    List<Video> findByTituloContainingIgnoreCase(String titulo);

    List<Video> findBySecao(String secao);
}