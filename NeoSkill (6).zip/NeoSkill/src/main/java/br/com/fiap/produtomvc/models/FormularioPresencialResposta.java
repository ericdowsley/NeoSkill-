package br.com.fiap.produtomvc.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;


import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Entity
@Table(name = "formularios_presenciais_respostas")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FormularioPresencialResposta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "formulario_id", nullable = false)
    private FormularioPresencial formulario;

    @ManyToOne
    @JoinColumn(name = "respondente_id", nullable = false)
    private Aluno respondente;

    @ElementCollection
    @CollectionTable(name = "respostas_perguntas", joinColumns = @JoinColumn(name = "resposta_id"))
    @MapKeyColumn(name = "pergunta")
    @Column(name = "resposta")
    @Builder.Default
    private Map<String, String> respostas = new HashMap<>();

    @Column(nullable = false)
    private LocalDateTime dataResposta;

    @PrePersist
    protected void onCreate() {
        dataResposta = LocalDateTime.now();
    }

    // Helper method to add a response
    public void addResposta(String pergunta, String resposta) {
        this.respostas.put(pergunta, resposta);
    }
}
