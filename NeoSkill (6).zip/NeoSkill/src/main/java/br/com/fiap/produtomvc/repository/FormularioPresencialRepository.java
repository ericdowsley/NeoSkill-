package br.com.fiap.produtomvc.repository;

import br.com.fiap.produtomvc.models.FormularioPresencial;
import br.com.fiap.produtomvc.models.Professor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface FormularioPresencialRepository extends JpaRepository<FormularioPresencial, Long> {

    // Find forms created by a specific user
    List<FormularioPresencial> findByCriador(Professor criador);

    // Find forms scheduled for a specific date range
    List<FormularioPresencial> findByDatatreinamentoBetween(LocalDateTime start, LocalDateTime end);

    // Find forms by title (case-insensitive, partial match)
    List<FormularioPresencial> findByTituloContainingIgnoreCase(String titulo);

    // Custom query to find forms with a specific number of questions
    @Query("SELECT f FROM FormularioPresencial f WHERE SIZE(f.perguntas) = :count")
    List<FormularioPresencial> findByQuestionCount(@Param("count") int count);

    // Find upcoming forms (scheduled in the future)
    @Query("SELECT f FROM FormularioPresencial f WHERE f.datatreinamento > CURRENT_TIMESTAMP")
    List<FormularioPresencial> findUpcomingForms();

    @Query("SELECT f FROM FormularioPresencial f LEFT JOIN FETCH f.perguntas WHERE f.id = :id")
    Optional<FormularioPresencial> findByIdWithPerguntas(@Param("id") Long id);
}