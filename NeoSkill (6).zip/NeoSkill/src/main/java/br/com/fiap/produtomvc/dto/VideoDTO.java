package br.com.fiap.produtomvc.dto;

import br.com.fiap.produtomvc.models.Video;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import org.hibernate.validator.constraints.URL;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VideoDTO {

    private Long id;

    @NotBlank(message = "O título é obrigatório")
    private String titulo;

    private String descricao;

    @NotBlank(message = "A URL do vídeo é obrigatória")
    @URL(message = "Forneça uma URL válida")
    private String url;

    @NotNull(message = "A seção é obrigatória")
    @PositiveOrZero(message = "A seção deve ser um número não negativo")
    private String secao;

    private Long professorId;

    public VideoDTO(Video entity) {
        id = entity.getId();
        titulo = entity.getTitulo();
        descricao = entity.getDescricao();
        url = entity.getUrl();
        secao = entity.getSecao();
    }

}