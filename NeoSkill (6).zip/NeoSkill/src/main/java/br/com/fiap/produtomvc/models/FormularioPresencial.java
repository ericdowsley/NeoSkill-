package br.com.fiap.produtomvc.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "formularios_presenciais")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FormularioPresencial {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String titulo;

    @Column(nullable = false)
    private LocalDateTime datatreinamento;

    @Column(length = 1000)
    private String descricao;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "perguntas_formulario", joinColumns = @JoinColumn(name = "formulario_id"))
    @Column(name = "pergunta")
    private List<String> perguntas = new ArrayList<>();

    @ManyToOne
    @JoinColumn(name = "criador_id")
    private Professor criador;

    // Helper method to add a question
    public void addPergunta(String pergunta) {
        this.perguntas.add(pergunta);
    }
}

