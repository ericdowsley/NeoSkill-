package br.com.fiap.produtomvc.controllers;

import br.com.fiap.produtomvc.dto.AlunoDTO;
import br.com.fiap.produtomvc.services.AlunoService;
import br.com.fiap.produtomvc.services.VideoService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/alunos")
public class AlunoController {

    @Autowired
    private AlunoService service;

    @Autowired
    private VideoService videoService;

    @GetMapping("/form")
    public String loadFormAluno(Model model) {
        model.addAttribute("alunoDTO", new AlunoDTO());
        return "aluno/novo-aluno";
    }

    @PostMapping()
    public String insert(@Valid AlunoDTO alunoDTO,
                         BindingResult result,
                         RedirectAttributes attributes) {
        if (result.hasErrors()) {
            return "aluno/novo-aluno";
        }
        alunoDTO = service.insert(alunoDTO);
        attributes.addFlashAttribute("mensagem", "Aluno salvo com sucesso!");
        return "redirect:/login";
    }

    @GetMapping()
    public String findAll(Model model) {
        List<AlunoDTO> alunosDTO = service.findAll();
        model.addAttribute("alunosDTO", alunosDTO);
        return "aluno/listar-alunos";
    }

    @GetMapping("/{id}")
    public String findById(@PathVariable("id") Long id, Model model) {
        AlunoDTO alunoDTO = service.findById(id);
        model.addAttribute("alunoDTO", alunoDTO);
        return "aluno/editar-aluno";
    }

    @PutMapping("/{id}")
    public String update(@PathVariable("id") Long id,
                         @Valid AlunoDTO alunoDTO,
                         BindingResult result,
                         RedirectAttributes attributes) {
        if (result.hasErrors()) {
            alunoDTO.setId(id);
            return "aluno/editar-aluno";
        }
        try {
            service.update(id, alunoDTO);
            attributes.addFlashAttribute("mensagem", "Aluno atualizado com sucesso!");
        } catch (Exception e) {
            attributes.addFlashAttribute("erro", "Erro ao atualizar aluno: " + e.getMessage());
        }
        return "redirect:/alunos";
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable("id") Long id, RedirectAttributes attributes) {
        try {
            service.delete(id);
            attributes.addFlashAttribute("mensagem", "Aluno excluído com sucesso!");
        } catch (Exception e) {
            attributes.addFlashAttribute("erro", "Erro ao excluir aluno: " + e.getMessage());
        }
        return "redirect:/alunos";
    }

    @GetMapping("/dashboard")
    public String showAlunoDashboard(HttpSession session, Model model) {
        AlunoDTO aluno = (AlunoDTO) session.getAttribute("usuario");
        if (aluno == null) {
            return "redirect:/login";
        }
        model.addAttribute("aluno", aluno);
        model.addAttribute("progresso", aluno.getProgresso());
        model.addAttribute("videos", videoService.findAll());
        return "aluno-dashboard";
    }

    @GetMapping("/perfilAluno")
    public String showProfile(HttpSession session, Model model) {
        AlunoDTO aluno = (AlunoDTO) session.getAttribute("usuario");
        if (aluno == null) {
            return "redirect:/login";
        }
        model.addAttribute("aluno", aluno);
        return "perfilAluno";
    }

    @GetMapping("/perfilAluno/editar")
    public String editProfile(HttpSession session, Model model) {
        AlunoDTO aluno = (AlunoDTO) session.getAttribute("usuario");
        if (aluno == null) {
            return "redirect:/login";
        }
        model.addAttribute("aluno", aluno);
        return "editar-perfilAluno";
    }

    @PostMapping("/perfilAluno/atualizar")
    public String updateProfile(@Valid @ModelAttribute AlunoDTO alunoDTO,
                                BindingResult result,
                                HttpSession session,
                                RedirectAttributes attributes) {
        if (result.hasErrors()) {
            return "editar-perfilAluno";
        }

        try {
            AlunoDTO updatedAluno = service.update(alunoDTO.getId(), alunoDTO);
            session.setAttribute("usuario", updatedAluno);
            attributes.addFlashAttribute("mensagem", "Perfil atualizado com sucesso!");
        } catch (Exception e) {
            attributes.addFlashAttribute("erro", "Erro ao atualizar perfil: " + e.getMessage());
            e.printStackTrace();
        }

        return "redirect:/alunos/perfilAluno";
    }

    @PostMapping("/{id}/progresso")
    public String updateProgresso(@PathVariable("id") Long id,
                                  @RequestParam("progresso") Double progresso,
                                  RedirectAttributes attributes) {
        try {
            service.updateProgresso(id, progresso);
            attributes.addFlashAttribute("mensagem", "Progresso atualizado com sucesso!");
        } catch (Exception e) {
            attributes.addFlashAttribute("erro", "Erro ao atualizar progresso: " + e.getMessage());
        }
        return "redirect:/alunos/dashboard";
    }
}