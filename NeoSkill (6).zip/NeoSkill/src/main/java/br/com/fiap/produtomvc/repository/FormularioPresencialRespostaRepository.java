package br.com.fiap.produtomvc.repository;

import br.com.fiap.produtomvc.models.FormularioPresencial;
import br.com.fiap.produtomvc.models.FormularioPresencialResposta;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FormularioPresencialRespostaRepository extends JpaRepository<FormularioPresencialResposta, Long> {
    List<FormularioPresencialResposta> findByFormulario(FormularioPresencial formulario);
}