package br.com.fiap.produtomvc.services;

import br.com.fiap.produtomvc.dto.VideoDTO;
import br.com.fiap.produtomvc.models.Video;
import br.com.fiap.produtomvc.models.Professor;
import br.com.fiap.produtomvc.repository.VideoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class VideoService {

    @Autowired
    private VideoRepository videoRepository;

    @Transactional
    public VideoDTO saveVideo(VideoDTO videoDTO, Professor professor) {
        Video video = new Video();
        video.setTitulo(videoDTO.getTitulo());
        video.setDescricao(videoDTO.getDescricao());
        video.setUrl(videoDTO.getUrl());
        video.setSecao(videoDTO.getSecao());
        video.setProfessor(professor);

        video = videoRepository.save(video);

        return convertToDTO(video);
    }

    @Transactional(readOnly = true)
    public List<VideoDTO> findAll() {
        return videoRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<VideoDTO> findByProfessor(Professor professor) {
        return videoRepository.findByProfessor(professor).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<VideoDTO> findByProfessorId(Long professorId) {
        return videoRepository.findByProfessorId(professorId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<VideoDTO> findByTitulo(String titulo) {
        return videoRepository.findByTituloContainingIgnoreCase(titulo).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<VideoDTO> findBySecao(String secao) {
        return videoRepository.findBySecao(secao).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public VideoDTO findById(Long id) {
        return videoRepository.findById(id)
                .map(this::convertToDTO)
                .orElseThrow(() -> new VideoNotFoundException("Vídeo não encontrado com ID: " + id));
    }

    @Transactional
    public VideoDTO updateVideo(Long id, VideoDTO videoDTO) {
        Video video = videoRepository.findById(id)
                .orElseThrow(() -> new VideoNotFoundException("Vídeo não encontrado com ID: " + id));

        video.setTitulo(videoDTO.getTitulo());
        video.setDescricao(videoDTO.getDescricao());
        video.setUrl(videoDTO.getUrl());
        video.setSecao(videoDTO.getSecao());



        video = videoRepository.save(video);

        return convertToDTO(video);
    }

    @Transactional
    public void deleteVideo(Long id) {
        videoRepository.deleteById(id);
    }

    private VideoDTO convertToDTO(Video video) {
        VideoDTO dto = new VideoDTO();
        dto.setId(video.getId());
        dto.setTitulo(video.getTitulo());
        dto.setDescricao(video.getDescricao());
        dto.setUrl(video.getUrl());
        dto.setSecao(video.getSecao());
        dto.setProfessorId(video.getProfessor().getId());
        return dto;
    }

    private Video convertToEntity(VideoDTO dto) {
        Video video = new Video();
        video.setId(dto.getId());
        video.setTitulo(dto.getTitulo());
        video.setDescricao(dto.getDescricao());
        video.setUrl(dto.getUrl());
        video.setSecao(dto.getSecao());
        return video;
    }

    public class VideoNotFoundException extends RuntimeException {
        public VideoNotFoundException(String message) {
            super(message);
        }
    }
}